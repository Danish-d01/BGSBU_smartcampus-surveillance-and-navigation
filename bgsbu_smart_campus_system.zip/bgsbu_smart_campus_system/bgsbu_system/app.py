"""
BGSBU Smart Campus Surveillance and Navigation System
=====================================================
Main Flask application entry point.
Handles video streaming, face/motion detection, admin panel, and navigation.
"""

from flask import Flask, render_template, Response, jsonify, send_from_directory
import cv2
import numpy as np
import os
import time
import threading

app = Flask(__name__)

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────
FACES_FOLDER    = os.path.join("static", "faces")
HAAR_CASCADE    = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
MOTION_THRESH   = 8000      # contour-area threshold (px²)
SAVE_INTERVAL   = 5         # seconds between auto-saves
BEEP_INTERVAL   = 3         # seconds between sound alerts

os.makedirs(FACES_FOLDER, exist_ok=True)

# ─────────────────────────────────────────────
# SHARED STATE (thread-safe primitives)
# ─────────────────────────────────────────────
state = {
    "face_detected"   : False,
    "motion_detected" : False,
    "last_save_time"  : 0,
    "last_beep_time"  : 0,
    "alert_message"   : "",
}

# ─────────────────────────────────────────────
# CAMERA & DETECTOR SETUP
# ─────────────────────────────────────────────
face_cascade   = cv2.CascadeClassifier(HAAR_CASCADE)
camera         = None
camera_lock    = threading.Lock()

def get_camera():
    """Lazy-initialise the webcam once and reuse it."""
    global camera
    with camera_lock:
        if camera is None or not camera.isOpened():
            camera = cv2.VideoCapture(0)
            camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    return camera

# Background-subtractor for robust motion detection
bg_subtractor = cv2.createBackgroundSubtractorMOG2(
    history=120, varThreshold=50, detectShadows=False
)

# ─────────────────────────────────────────────
# FRAME PROCESSING
# ─────────────────────────────────────────────
def process_frame(frame, prev_gray):
    """
    Apply face detection + motion detection to a single frame.
    Returns (annotated_frame, updated_prev_gray).
    """
    # Mirror the frame horizontally for natural webcam feel
    frame = cv2.flip(frame, 1)

    gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray  = cv2.GaussianBlur(gray, (21, 21), 0)

    # ── Face Detection ──────────────────────────────
    faces = face_cascade.detectMultiScale(
        gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40)
    )
    state["face_detected"] = len(faces) > 0

    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(frame, "Face", (x, y - 8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    if state["face_detected"]:
        cv2.putText(frame, "FACE DETECTED", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

    # ── Motion Detection (frame differencing + MOG2) ──
    motion_detected = False
    if prev_gray is not None:
        frame_diff = cv2.absdiff(prev_gray, gray)
        _, thresh  = cv2.threshold(frame_diff, 25, 255, cv2.THRESH_BINARY)
        thresh     = cv2.dilate(thresh, None, iterations=2)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for cnt in contours:
            if cv2.contourArea(cnt) > MOTION_THRESH:
                motion_detected = True
                (mx, my, mw, mh) = cv2.boundingRect(cnt)
                cv2.rectangle(frame, (mx, my), (mx + mw, my + mh), (0, 0, 255), 2)

    state["motion_detected"] = motion_detected

    if motion_detected:
        cv2.putText(frame, "SUDDEN MOVEMENT DETECTED", (10, 65),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 0, 255), 2)

        now = time.time()
        # Auto-save captured frame every SAVE_INTERVAL seconds
        if now - state["last_save_time"] > SAVE_INTERVAL:
            filename = os.path.join(
                FACES_FOLDER,
                f"alert_{time.strftime('%Y%m%d_%H%M%S')}.jpg"
            )
            cv2.imwrite(filename, frame)
            state["last_save_time"] = now

    # Overlay timestamp
    ts = time.strftime("%Y-%m-%d  %H:%M:%S")
    cv2.putText(frame, ts, (10, frame.shape[0] - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (200, 200, 200), 1)

    return frame, gray


# ─────────────────────────────────────────────
# VIDEO GENERATOR (MJPEG stream)
# ─────────────────────────────────────────────
def generate_frames():
    """Yield MJPEG frames for the /video route."""
    cam       = get_camera()
    prev_gray = None

    while True:
        success, frame = cam.read()
        if not success:
            # Send a blank frame on read failure
            blank = np.zeros((480, 640, 3), dtype=np.uint8)
            cv2.putText(blank, "Camera Unavailable", (160, 240),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            _, buf = cv2.imencode(".jpg", blank)
            yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + buf.tobytes() + b"\r\n")
            time.sleep(0.1)
            continue

        frame, prev_gray = process_frame(frame, prev_gray)

        _, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
        yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + buf.tobytes() + b"\r\n")


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@app.route("/")
def index():
    """User landing page."""
    return render_template("index.html")


@app.route("/admin")
def admin():
    """Admin dashboard – live camera view."""
    return render_template("admin.html")


@app.route("/logs")
def logs():
    """Admin logs – view saved alert images."""
    images = sorted(os.listdir(FACES_FOLDER), reverse=True)
    images = [f for f in images if f.endswith((".jpg", ".png", ".jpeg"))]
    return render_template("logs.html", images=images)


@app.route("/navigation")
def navigation():
    """Campus navigation map page."""
    return render_template("navigation.html")


@app.route("/video")
def video():
    """MJPEG stream endpoint."""
    return Response(
        generate_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame"
    )


@app.route("/status")
def status():
    """JSON endpoint for live alert status (polled by frontend)."""
    return jsonify({
        "face_detected"   : state["face_detected"],
        "motion_detected" : state["motion_detected"],
    })


@app.route("/static/faces/<filename>")
def serve_face(filename):
    return send_from_directory(FACES_FOLDER, filename)


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    print("\n╔══════════════════════════════════════════════╗")
    print("║  BGSBU Smart Campus Surveillance System      ║")
    print("║  http://127.0.0.1:5000                       ║")
    print("╚══════════════════════════════════════════════╝\n")
    app.run(debug=True, threaded=True, use_reloader=False)
