/**
 * admin.js – Admin panel live status, detection log, and beep alert.
 * Polls /status every 1.5s. Plays a Web Audio beep on motion events.
 */

// ── DOM refs ──────────────────────────────────────────────
const faceAlertEl   = document.getElementById("faceAlert");
const motionAlertEl = document.getElementById("motionAlert");
const faceStatusEl  = document.getElementById("faceStatus");
const motionStatusEl= document.getElementById("motionStatus");
const logEl         = document.getElementById("detectionLog");
const clockEl       = document.getElementById("liveClock");

// ── Web Audio Context ─────────────────────────────────────
const ctx = new (window.AudioContext || window.webkitAudioContext)();
let lastBeepTime = 0;

function beep(freq = 660, dur = 0.22) {
  const now = Date.now();
  if (now - lastBeepTime < 3000) return;
  lastBeepTime = now;

  const osc  = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.type = "sawtooth";
  osc.frequency.setValueAtTime(freq, ctx.currentTime);
  gain.gain.setValueAtTime(0.12, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + dur);
}

// ── Live Clock ────────────────────────────────────────────
function updateClock() {
  if (clockEl) clockEl.textContent = new Date().toLocaleTimeString();
}
setInterval(updateClock, 1000);
updateClock();

// ── Log Helper ────────────────────────────────────────────
function addLog(msg, type = "log-info") {
  const ts   = new Date().toLocaleTimeString();
  const entry= document.createElement("div");
  entry.className = `log-entry ${type}`;
  entry.textContent = `[${ts}] ${msg}`;
  logEl.prepend(entry);

  // Keep last 60 entries
  while (logEl.children.length > 60) logEl.removeChild(logEl.lastChild);
}

// ── State tracking to avoid duplicate log entries ─────────
let prevFace   = false;
let prevMotion = false;

// ── Status Polling ────────────────────────────────────────
async function pollStatus() {
  try {
    const res  = await fetch("/status");
    const data = await res.json();

    // Face detected
    if (data.face_detected) {
      faceAlertEl.classList.add("active");
      faceStatusEl.textContent = "DETECTED";
      if (!prevFace) addLog("Face detected in frame.", "log-face");
    } else {
      faceAlertEl.classList.remove("active");
      faceStatusEl.textContent = "IDLE";
      if (prevFace) addLog("Face left frame.", "log-info");
    }

    // Motion detected
    if (data.motion_detected) {
      motionAlertEl.classList.add("active");
      motionStatusEl.textContent = "ALERT";
      if (!prevMotion) addLog("⚠ Sudden movement detected!", "log-alert");
      beep();
    } else {
      motionAlertEl.classList.remove("active");
      motionStatusEl.textContent = "IDLE";
      if (prevMotion) addLog("Motion subsided.", "log-warn");
    }

    prevFace   = data.face_detected;
    prevMotion = data.motion_detected;

  } catch (_) {
    addLog("Connection error – retrying…", "log-warn");
  }
}

// Resume audio on first interaction
document.addEventListener("click", () => {
  if (ctx.state === "suspended") ctx.resume();
}, { once: true });

function clearLog() {
  logEl.innerHTML = '<div class="log-entry log-info">Log cleared.</div>';
}

setInterval(pollStatus, 1500);
pollStatus();
