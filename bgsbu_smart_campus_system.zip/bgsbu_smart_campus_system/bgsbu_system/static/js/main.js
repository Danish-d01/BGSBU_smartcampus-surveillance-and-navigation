/**
 * main.js – Landing page status polling + alert beep (Web Audio API)
 * Polls /status every 2 seconds and updates UI indicators.
 */

const faceDot    = document.getElementById("faceDot");
const motionDot  = document.getElementById("motionDot");
const alertBanner = document.getElementById("alertBanner");
const alertText   = document.getElementById("alertText");

let lastBeepTime = 0;
const BEEP_INTERVAL_MS = 3000;

// ── Web Audio beep (no external file needed) ──────────────
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

function playBeep(freq = 880, duration = 0.18) {
  const now = Date.now();
  if (now - lastBeepTime < BEEP_INTERVAL_MS) return;
  lastBeepTime = now;

  const osc   = audioCtx.createOscillator();
  const gain  = audioCtx.createGain();
  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.type      = "square";
  osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
  gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);

  osc.start(audioCtx.currentTime);
  osc.stop(audioCtx.currentTime + duration);
}

// ── Status Polling ────────────────────────────────────────
async function pollStatus() {
  try {
    const res  = await fetch("/status");
    const data = await res.json();

    // Face detection dot
    if (data.face_detected) {
      faceDot.className  = "dot dot-green";
    } else {
      faceDot.className  = "dot";
    }

    // Motion detection dot
    if (data.motion_detected) {
      motionDot.className = "dot dot-red";
      alertBanner.style.display = "block";
      alertText.textContent = "⚠️  Sudden Movement Detected!";
      playBeep();
    } else {
      motionDot.className = "dot";
    }

    // Unified alert banner
    if (data.face_detected && !data.motion_detected) {
      alertBanner.style.display = "block";
      alertText.textContent = "👤  Face Detected on Camera";
    }

    if (!data.face_detected && !data.motion_detected) {
      alertBanner.style.display = "none";
    }

  } catch (_) {
    /* Backend not running – silent fail */
  }
}

// Resume AudioContext on first user interaction (browser policy)
document.addEventListener("click", () => {
  if (audioCtx.state === "suspended") audioCtx.resume();
}, { once: true });

setInterval(pollStatus, 2000);
pollStatus(); // immediate first call
