/**
 * navigation.js
 * ─────────────
 * Leaflet.js map centred on BGSBU campus (Rajouri, J&K).
 * Features:
 *   - Satellite (Esri) + Street (OSM) layer toggle
 *   - Campus location markers with popups
 *   - OSRM routing for walk / drive / cycle
 *   - Straight-line fallback when OSRM returns no route
 */

// ── Campus Coordinates ────────────────────────────────────
const CAMPUS_CENTER = [33.396290, 74.347233];

// Campus POI data — real BGSBU Rajouri coordinates
const LOCATIONS = [
  { name:"Gate",                      lat:33.397828, lng:74.347233, desc:"Main entrance gate to BGSBU campus",           color:"#00c6ff" },
  { name:"SOET",                      lat:33.394923, lng:74.351739, desc:"School of Engineering & Technology",           color:"#0072ff" },
  { name:"Nursing Department",        lat:33.395913, lng:74.351495, desc:"Department of Nursing Sciences",               color:"#ff4081" },
  { name:"Girls Hostel",              lat:33.395084, lng:74.346225, desc:"Girls residential hostel",                     color:"#e040fb" },
  { name:"Management Department",     lat:33.394949, lng:74.348346, desc:"School of Business & Management",             color:"#ff9800" },
  { name:"ITE",                       lat:33.394342, lng:74.350677, desc:"Institute of Technology & Engineering",        color:"#8c9eff" },
  { name:"EE and ECE",                lat:33.394636, lng:74.350849, desc:"Electrical Engineering & Electronics dept",    color:"#00bcd4" },
  { name:"Admin Block",               lat:33.396042, lng:74.346723, desc:"Administrative offices & Registrar",           color:"#ffd600" },
  { name:"Polytechnique",             lat:33.396655, lng:74.349221, desc:"Polytechnic Institute building",               color:"#76ff03" },
  { name:"IT and CS",                 lat:33.394846, lng:74.348320, desc:"Information Technology & Computer Science",    color:"#00e676" },
  { name:"Central Library",           lat:33.395621, lng:74.347304, desc:"Central Library — books, journals & digital archive", color:"#ffd600" },
  { name:"VC Secretariat",            lat:33.395732, lng:74.347067, desc:"Vice Chancellor's office & Secretariat",      color:"#ff3b3b" },
  { name:"Islamic Studies",           lat:33.395398, lng:74.347848, desc:"Department of Islamic Studies",               color:"#00c6ff" },
  { name:"CE Workshop",               lat:33.396049, lng:74.352883, desc:"Civil Engineering Workshop",                  color:"#ff6d00" },
  { name:"Nursing Hostel",            lat:33.396436, lng:74.352894, desc:"Residential hostel for Nursing students",     color:"#ff4081" },
  { name:"BJRC Hostel",               lat:33.393134, lng:74.347414, desc:"BJRC Boys residential hostel",               color:"#ff9800" },
  { name:"APJ Hostel",                lat:33.392938, lng:74.346286, desc:"APJ Abdul Kalam Boys hostel",                 color:"#ff6d00" },
  { name:"BGSBU Viewpoint",           lat:33.391597, lng:74.346003, desc:"Scenic viewpoint overlooking the campus",    color:"#00e676" },
  { name:"Boys Hostel A/B Block",     lat:33.394767, lng:74.344362, desc:"Boys residential hostel A & B blocks",       color:"#ff6d00" },
  { name:"Sociology Department",      lat:33.394601, lng:74.344760, desc:"Department of Sociology",                    color:"#e040fb" },
  { name:"Student Amenities",         lat:33.393983, lng:74.344813, desc:"Student welfare & amenities centre",         color:"#00bcd4" },
  { name:"Hospitality and Tourism",   lat:33.394149, lng:74.344283, desc:"Dept of Hospitality Management & Tourism",   color:"#8c9eff" },
  { name:"Maths/English/Urdu Dept",   lat:33.394192, lng:74.344008, desc:"Mathematics, English & Urdu departments",   color:"#76ff03" },
  { name:"Biodiversity Sciences",     lat:33.393984, lng:74.341105, desc:"Department of Biodiversity & Conservation", color:"#00e676" },
];

// ── Map Init ──────────────────────────────────────────────
const map = L.map("map", { zoomControl: true, attributionControl: true });
map.setView(CAMPUS_CENTER, 16);

// ── Tile Layers ───────────────────────────────────────────
const satelliteLayer = L.tileLayer(
  "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
  { attribution: "Tiles © Esri — Source: Esri, USGS, NOAA", maxZoom: 19 }
);

const streetLayer = L.tileLayer(
  "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
  { attribution: "© OpenStreetMap contributors", maxZoom: 19 }
);

satelliteLayer.addTo(map); // default: satellite

// Active travel mode
let travelMode = "foot";

// Route polyline reference
let routeLine = null;

// ── Custom Marker SVG Factory ─────────────────────────────
function makeIcon(color) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="28" height="36" viewBox="0 0 28 36">
    <path d="M14 0C6.27 0 0 6.27 0 14c0 9.33 14 22 14 22S28 23.33 28 14C28 6.27 21.73 0 14 0z"
      fill="${color}" stroke="#fff" stroke-width="2"/>
    <circle cx="14" cy="14" r="5" fill="white" opacity="0.9"/>
  </svg>`;
  return L.divIcon({
    html: svg,
    className: "",
    iconSize: [28, 36],
    iconAnchor: [14, 36],
    popupAnchor: [0, -36]
  });
}

// ── Place Markers ─────────────────────────────────────────
const markerMap = {}; // name → L.Marker

LOCATIONS.forEach(loc => {
  const marker = L.marker([loc.lat, loc.lng], { icon: makeIcon(loc.color) })
    .addTo(map)
    .bindPopup(`
      <div class="popup-title">${loc.name}</div>
      <div class="popup-desc">${loc.desc}</div>
      <div class="popup-coords">${loc.lat.toFixed(6)}, ${loc.lng.toFixed(6)}</div>
    `);
  markerMap[loc.name] = marker;
});

// ── Populate Dropdowns ────────────────────────────────────
const srcSelect = document.getElementById("srcSelect");
const dstSelect = document.getElementById("dstSelect");

LOCATIONS.forEach(loc => {
  [srcSelect, dstSelect].forEach(sel => {
    const opt = document.createElement("option");
    opt.value = loc.name;
    opt.textContent = loc.name;
    sel.appendChild(opt);
  });
});

// ── Populate Location Sidebar List ────────────────────────
const locListEl = document.getElementById("locationList");
LOCATIONS.forEach(loc => {
  const item = document.createElement("div");
  item.className = "loc-item";
  item.innerHTML = `<div class="loc-dot" style="background:${loc.color}"></div>${loc.name}`;
  item.addEventListener("click", () => {
    map.setView([loc.lat, loc.lng], 18);
    markerMap[loc.name].openPopup();
  });
  locListEl.appendChild(item);
});

// ── Layer Toggle ──────────────────────────────────────────
function setLayer(type) {
  if (type === "satellite") {
    if (!map.hasLayer(satelliteLayer)) map.addLayer(satelliteLayer);
    if ( map.hasLayer(streetLayer))   map.removeLayer(streetLayer);
    document.getElementById("btnSatellite").classList.add("active");
    document.getElementById("btnStreet").classList.remove("active");
  } else {
    if (!map.hasLayer(streetLayer))   map.addLayer(streetLayer);
    if ( map.hasLayer(satelliteLayer))map.removeLayer(satelliteLayer);
    document.getElementById("btnStreet").classList.add("active");
    document.getElementById("btnSatellite").classList.remove("active");
  }
}

// ── Mode Toggle ───────────────────────────────────────────
function setMode(mode) {
  travelMode = mode;
  document.querySelectorAll(".mode-btn").forEach(b => b.classList.remove("active"));
  const map2btn = { foot:"modeWalk", car:"modeDrive", bike:"modeCycle" };
  document.getElementById(map2btn[mode]).classList.add("active");
}

// ── Status Helper ─────────────────────────────────────────
function setStatus(msg) {
  document.getElementById("mapStatus").textContent = msg;
}

// ── Draw Fallback Straight Line ───────────────────────────
function drawFallback(src, dst) {
  if (routeLine) map.removeLayer(routeLine);
  routeLine = L.polyline([[src.lat, src.lng], [dst.lat, dst.lng]], {
    color: "#ffd600", weight: 3, dashArray: "8 6", opacity: 0.85
  }).addTo(map);
  map.fitBounds(routeLine.getBounds(), { padding: [40, 40] });

  const dist = map.distance([src.lat, src.lng], [dst.lat, dst.lng]);
  showRouteInfo(`~${(dist/1000).toFixed(2)} km (straight)`, "—", travelMode);
  setStatus("Fallback: straight-line route shown");
}

// ── Show Route Info Panel ─────────────────────────────────
function showRouteInfo(dist, dur, mode) {
  document.getElementById("routeInfo").style.display = "block";
  document.getElementById("routeDist").textContent = dist;
  document.getElementById("routeDur").textContent  = dur;
  document.getElementById("routeMode").textContent = { foot:"Walking", car:"Driving", bike:"Cycling" }[mode] || mode;
}

// ── Get Route via OSRM ────────────────────────────────────
async function getRoute() {
  const srcName = srcSelect.value;
  const dstName = dstSelect.value;

  if (!srcName || !dstName) { setStatus("⚠ Please select source and destination"); return; }
  if (srcName === dstName)  { setStatus("⚠ Source and destination are the same"); return; }

  const src = LOCATIONS.find(l => l.name === srcName);
  const dst = LOCATIONS.find(l => l.name === dstName);

  setStatus("Fetching route…");

  // OSRM expects: longitude,latitude
  const profile  = travelMode; // foot | car | bike
  const osrmURL  = `https://router.project-osrm.org/route/v1/${profile}/` +
                   `${src.lng},${src.lat};${dst.lng},${dst.lat}` +
                   `?overview=full&geometries=geojson`;

  try {
    const res  = await fetch(osrmURL);
    const data = await res.json();

    if (data.code === "Ok" && data.routes && data.routes.length > 0) {
      const route    = data.routes[0];
      const coords   = route.geometry.coordinates.map(c => [c[1], c[0]]); // swap to [lat,lng]
      const distKm   = (route.distance / 1000).toFixed(2);
      const durMin   = Math.ceil(route.duration / 60);

      if (routeLine) map.removeLayer(routeLine);
      routeLine = L.polyline(coords, {
        color: "#00c6ff", weight: 5, opacity: 0.9
      }).addTo(map);
      map.fitBounds(routeLine.getBounds(), { padding: [50, 50] });

      showRouteInfo(`${distKm} km`, `${durMin} min`, travelMode);
      setStatus(`Route found: ${distKm} km, ~${durMin} min`);

    } else {
      // OSRM returned no route (remote campus – sparse road network)
      setStatus("No OSRM route – showing straight-line fallback");
      drawFallback(src, dst);
    }

  } catch (err) {
    console.warn("OSRM fetch failed:", err);
    setStatus("OSRM unavailable – fallback route shown");
    drawFallback(src, dst);
  }
}

// ── Expose to HTML onclick ────────────────────────────────
window.setLayer  = setLayer;
window.setMode   = setMode;
window.getRoute  = getRoute;

// ── Init status ───────────────────────────────────────────
setStatus("Map ready · BGSBU Campus");
